package com.example.task3_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;


public class MainActivity extends AppCompatActivity {
    private static TextView result;

    private boolean lastNumeric = false;
    private boolean stateError = false;
    private boolean lastDot = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        result = findViewById(R.id.result);
    }
    public void onDigit(View view) {
        if (stateError) {
            result.setText(((Button) view).getText());
            stateError = false;
        } else {
            result.append(((Button) view).getText());
        }
        lastNumeric = true;
    }

    public void onOperator(View view) {
        if (lastNumeric && !stateError) {
            result.append(((Button) view).getText());
            lastNumeric = false;
            lastDot = false;    // Reset the DOT flag
        }
    }

    public void onClear(View view) {
        result.setText("");
        lastNumeric = false;
        stateError = false;
        lastDot = false;
    }

    public void onEqual(View view) {
        if (lastNumeric && !stateError) {
            String txt = result.getText().toString();

            try {
                Expression expression = new ExpressionBuilder(txt).build();
                double ans = expression.evaluate();
                result.setText(Double.toString(ans));
                lastDot = true;
            } catch (ArithmeticException ex) {
                result.setText("Error");
                stateError = true;
                lastNumeric = false;
            }
        }
    }
}