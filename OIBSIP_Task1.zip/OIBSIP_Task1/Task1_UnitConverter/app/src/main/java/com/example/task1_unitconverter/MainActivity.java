package com.example.task1_unitconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
   Button convertButton;
   EditText inputEditText;
   Spinner spinnerFrom, spinnerTo;
   TextView resultTextview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inputEditText = findViewById(R.id.textInput);
        spinnerFrom = findViewById(R.id.spinnerFrom);
        spinnerTo = findViewById(R.id.spinnerTo);
        convertButton = findViewById(R.id.convertButton);
        resultTextview = findViewById(R.id.resultTextView);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.Units_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFrom.setAdapter(adapter);
        spinnerTo.setAdapter(adapter);

        // Set up the convert button click listener
        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convert();
            }
        });

    }
    private void convert() {
        // Get user input
        String inputValueStr = inputEditText.getText().toString().trim();
        if (inputValueStr.isEmpty()) {
            resultTextview.setText("Please enter a value");
            return;
        }

        double inputValue = Double.parseDouble(inputValueStr);

        // Get selected units from spinners
        String unitFrom = spinnerFrom.getSelectedItem().toString();
        String unitTo = spinnerTo.getSelectedItem().toString();

        // Perform the conversion
        double result = performConversion(inputValue, unitFrom, unitTo);

        // Display the result
        String resultStr = String.format("%.2f %s = %.2f %s", inputValue, unitFrom, result, unitTo);
        resultTextview.setText(resultStr);
    }

    private double performConversion(double value, String unitFrom, String unitTo) {
        // Implement conversion logic based on the selected units
        // Add more conversion options as needed
        if (unitFrom.equals("Centimeters") && unitTo.equals("Meters")) {
            return value / 100.0;
        } else if (unitFrom.equals("Grams") && unitTo.equals("Kilograms")) {
            return value / 1000.0;
        }
        if (unitFrom.equals("Meters") && unitTo.equals("Centimeters")) {
            return value * 100.0;
        } else if (unitFrom.equals("Kilograms") && unitTo.equals("Grams")) {
            return value * 1000.0;
        }
               else {
            // If units are not recognized, return the input value
            return value;
        }
    }
}