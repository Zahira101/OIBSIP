package com.example.stopwatch;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.MessageFormat;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    TextView time;
    Button startButton, stopButton,holdButton;
    int min, sec, milliseconds;
    long millisecond, startTime, bufftime, updatetime = 0L;
    Handler handler;
    private final Runnable runnable = new Runnable() {
        @Override
        public void run() {
            millisecond = SystemClock.uptimeMillis()-startTime;
            updatetime = bufftime+millisecond;
            sec = (int) (updatetime/1000);
            min = sec/60;
            sec = sec %60;
            milliseconds = (int) (updatetime % 1000);
            time.setText(MessageFormat.format("{0}:{1}:{2}",min,
                    String.format(Locale.getDefault(),"%02d",sec),
                    String.format(Locale.getDefault(),"%02d",milliseconds)));
            handler.postDelayed(this,0);

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        time = (TextView) findViewById(R.id.time);

         startButton = (Button) findViewById(R.id.start_button);
         stopButton = (Button) findViewById(R.id.stop_Button);
         holdButton = (Button) findViewById(R.id.hold_Button);
         handler = new Handler(Looper.getMainLooper());
         startButton.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 startTime = SystemClock.uptimeMillis();
                 handler.postDelayed(runnable,0);
                 holdButton.setEnabled(true);
                 stopButton.setEnabled(false);
                 startButton.setEnabled(false);

             }
         });

         holdButton.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 bufftime+=millisecond;
                 handler.removeCallbacks(runnable);

                 stopButton.setEnabled(true);
                 holdButton.setEnabled(false);
                 startButton.setEnabled(true);


             }
         });
        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                millisecond = 0L;
                bufftime = 0L;
                startTime = 0L;
                updatetime = 0L;
                sec = 0;
                min = 0;
                milliseconds = 0;
                time.setText("00:00:00");
            }
        });
         time.setText("00:00:00");
    }


}